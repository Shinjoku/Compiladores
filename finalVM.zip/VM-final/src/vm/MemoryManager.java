package vm;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.IndexOutOfBoundsException;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

class MemoryManager {
	
	// Variáveis
	private List<Integer> dataStack;
	private int stackPointer;
        private int funValor =0;
        
	public MemoryManager() {
		this.dataStack = new ArrayList<Integer>();
		this.stackPointer = 0;
	}
	
	public void setFunValor(int valor){
            this.funValor = valor;
        }
        
        
        
	// Getters
	public int getFunValor(){
            return this.funValor;
        }
	public List getDataStack(){
		return this.dataStack;
	}
	
	
	// Setters
	private void setSP(int value){
		this.stackPointer = value;
	}
	
	
	// Métodos
	
	public void printState() {
            System.out.println(this.stackPointer);
            System.out.println("Pilha de dados: --------------------");
            for(int count=0; count < dataStack.size(); count++){
                System.out.print(dataStack.get(count)+  " ");
            }
                    
            System.out.println("\n------------------------------------");
	}
	
	
	// Instruções
	
	// S:= s - 1
	public void start() {
		stackPointer = -1;
	}
	
	// S = s + 1, M[s] = k
	public void ldc(String kI) {
            int k=0;
            k = Integer.valueOf(kI);
            dataStack.add(0);
            stackPointer++;
            dataStack.set(stackPointer, k);
            //System.out.println(stackPointer);
	}
	
	// S = s + 1, M[s] = M[n]
	public void ldv(String nI) {
            int n =0;
            n = Integer.valueOf(nI);
            dataStack.add(0);
            stackPointer++;
            dataStack.set(stackPointer, dataStack.get(n));
	}
	
	// M[s - 1] = M[s - 1] + M[s], S = s - 1
	public void add() {
		dataStack.set(stackPointer-1, dataStack.get(stackPointer-1)+dataStack.get(stackPointer));
                dataStack.remove(stackPointer);
                stackPointer--;
	}
	
	// M[s - 1] = M[s - 1] - M[s], S = s - 1
	public void sub() {
		dataStack.set(stackPointer-1, dataStack.get(stackPointer-1)-dataStack.get(stackPointer));
                dataStack.remove(stackPointer);
                stackPointer--;
	}
	
	// M[s - 1] = M[s - 1] * M[s], S = s - 1
	public void mult() {
            dataStack.set(stackPointer-1, dataStack.get(stackPointer-1)*dataStack.get(stackPointer));
            dataStack.remove(stackPointer);
            stackPointer--;
	}
	
	// M[s - 1] = M[s - 1] / M[s], S = s - 1
	public void divi() {
            dataStack.set(stackPointer-1, dataStack.get(stackPointer-1)/dataStack.get(stackPointer));
            dataStack.remove(stackPointer);
            stackPointer--;
	}
	
	// M[s] = -M[s]
	public void inv() {
            dataStack.set(stackPointer, dataStack.get(stackPointer)*-1);
	}
	
	// se M [s-1] = 1 e M[s] = 1  então M[s-1]:=1  senão M[s-1]:=0;  s:=s - 1 
	public void and() {
            if(dataStack.get(stackPointer-1) == 1 && dataStack.get(stackPointer) == 1)
                    dataStack.set(stackPointer-1, 1);
            else
                    dataStack.set(stackPointer-1, 0);

            dataStack.remove(stackPointer);
            stackPointer--;
	}
	
	// se M[s-1] = 1  ou M[s] = 1  então M[s-1] =1  senão M[s-1] =0; s =s - 1 
	public void or() {
            if(dataStack.get(stackPointer-1) == 1 || dataStack.get(stackPointer) == 1)
                    dataStack.set(stackPointer-1, 1);
            else
                    dataStack.set(stackPointer-1, 0);

            dataStack.remove(stackPointer);
            stackPointer--;
	}
	
	//  M[s]:=1 - M[s] 
	public void neg() {
            dataStack.set(stackPointer, 1-dataStack.get(stackPointer));
	}
	
	// se M[s-1] < M[s]  então M[s-1]:=1 senão M[s-1]:=0; s:=s - 1 
	public void cme() {
            if(dataStack.get(stackPointer-1) < dataStack.get(stackPointer))
                    dataStack.set(stackPointer-1, 1);
            else
                    dataStack.set(stackPointer-1, 0);

            dataStack.remove(stackPointer);
            stackPointer--;
	}
	
	// se M[s-1] > M[s]  então M[s-1]:=1 senão M[s-1]:=0; s:=s - 1 
	public void cma() {
            if(dataStack.get(stackPointer-1) > dataStack.get(stackPointer))
                    dataStack.set(stackPointer-1, 1);
            else
                    dataStack.set(stackPointer-1, 0);

            dataStack.remove(stackPointer);
            stackPointer--;
	}
	
	// se M[s-1] = M[s]  então M[s-1]:=1 senão M[s-1]:=0; s:=s - 1 
	public void ceq() {
		if(dataStack.get(stackPointer-1).equals(dataStack.get(stackPointer)) )
			dataStack.set(stackPointer-1, 1);
		else
			dataStack.set(stackPointer-1, 0);
		
                dataStack.remove(stackPointer);
                stackPointer--;
	}
	
	// se M[s-1] != M[s]  então M[s-1]:=1 senão M[s-1]:=0; s:=s - 1 
	public void cdif() {
		if(!dataStack.get(stackPointer-1).equals(dataStack.get(stackPointer)) )
			dataStack.set(stackPointer-1, 1);
		else
			dataStack.set(stackPointer-1, 0);
		
                dataStack.remove(stackPointer);
                stackPointer--;
	}

	// se M[s-1] <= M[s]  então M[s-1]:=1 senão M[s-1]:=0; s:=s - 1 
	public void cmeq() {
		if(dataStack.get(stackPointer-1) <= dataStack.get(stackPointer))
			dataStack.set(stackPointer-1, 1);
		else
			dataStack.set(stackPointer-1, 0);
		
                dataStack.remove(stackPointer);
                stackPointer--;
	}
	
	// se M[s-1] >= M[s]  então M[s-1]:=1 senão M[s-1]:=0; s:=s - 1 
	public void cmaq() {
		if(dataStack.get(stackPointer-1) >= dataStack.get(stackPointer))
			dataStack.set(stackPointer-1, 1);
		else
			dataStack.set(stackPointer-1, 0);
		
                dataStack.remove(stackPointer);
                stackPointer--;
	}

	// M[n]:= M[s]; s:= s-1 
	public void str(String n) {
		int actualPoint = 0;
                actualPoint = Integer.valueOf(n);
		dataStack.set(actualPoint, dataStack.get(stackPointer));
                dataStack.remove(stackPointer);
                stackPointer--;
		
	}
	
	// i = t
	public int jmp(Object p, TableModel model) {
            String searchValor=null;
            searchValor = String.valueOf(p);
            for(int count=0; count<=model.getRowCount(); count++){
                if(model.getValueAt(count, 0).equals(searchValor)){
                    return count;
                }
            }
            return -1;
	}
	
	// se M[s] = 0 então i:=t senão i:=i + 1; s:=s-1 
	public int jmpf(Object p, TableModel model) {
            String searchValor =null;
            searchValor = String.valueOf(p);
		if(dataStack.get(stackPointer).equals(0)){
                    for(int count=0; count<=model.getRowCount(); count++){
                        if(model.getValueAt(count, 0).equals(searchValor)){
                            dataStack.remove(stackPointer);
                            stackPointer--;
                            return count;
                        }
                        else{
                            
                        }
                    }
                    return -1;
                }
                else{
                    dataStack.remove(stackPointer);
                    stackPointer--;
                    return -2;
                }
	}

	// S:=s + 1; M[s]:= “próximo valor de entrada”. 	
	public void rd(String value) {
            int inputValor =0;
            inputValor = Integer.valueOf(value);
            dataStack.add(inputValor);
            stackPointer++;
	}
	
	//  “Imprimir M[s]”; s:=s-1
	public int prn() {
		int returnValor =0;
                returnValor =dataStack.get(stackPointer);
                dataStack.remove(stackPointer);
                stackPointer--;
                return returnValor;
	}
	
	// Para k:=0 até n-1 faça {s:=s + 1; M[s]:=M[m+k]} 
	public void alloc(String mI, String nI) {
		int k, value, m=0, n=0;
                
                m = Integer.valueOf(mI);
                n = Integer.valueOf(nI);
		for(k = 0; k <= (n - 1); k++) {
                    dataStack.add(0);
                    stackPointer++;
                    dataStack.set(stackPointer, dataStack.get(m+k));
                    dataStack.set(m+k, 0);
                }
                //System.out.println(stackPointer);
	}
	
	// Para k:=n-1 até 0 faça {M[m+k]:=M[s]; s:=s - 1} 
	public void dalloc(String mI, String nI) {
            int k, m=0, n=0;
            int actualValue;

            m = Integer.valueOf(mI);
            n = Integer.valueOf(nI);
            for (k = (n-1); k >= 0; k--) {
                dataStack.set(m+k, dataStack.get(stackPointer));
                dataStack.remove(stackPointer);
                stackPointer--;
            }
	}
	
	// S:=s + 1; M[s]:= i+ 1; i:=t 
	public int call(Object p, TableModel model, int countColum) {
            //procura pulo
            for(int count =0; count <= model.getRowCount(); count++){
                if(model.getValueAt(count, 0).equals(p)){
                    //salva posicao que saiu para retornar depois
                    dataStack.add(countColum);
                    stackPointer++;
                    return count;
                }
            }
            return -1;
	}
	
	// i:=M[s]; s:=s - 1 
	public int retrn() {
		int returnValor =0;
                //System.out.println("vm.MemoryManager.retrn() "+ dataStack.get(dataStack.size()));
                //System.out.println("vm.MemoryManager.retrn() "+stackPointer);
                returnValor = dataStack.get(stackPointer);
                //System.out.println("vm.MemoryManager.retrn() "+ returnValor);
                dataStack.remove(stackPointer);
                stackPointer--;
                return returnValor;
	}
        
        public int retrnf(){
            int returnValor =0;
            //pegar o topa da pilha como retorno da função
            funValor = dataStack.get(stackPointer);
            dataStack.remove(stackPointer);
            stackPointer--;
            //pegar posicao de retorno salva pelo call
            returnValor = this.retrn();
            //joga resultado no topo da pilha para ser usado na proxima
            dataStack.add(funValor);
            stackPointer++;
            System.out.println("vm.MemoryManager.retrnf() return position:"+ returnValor);
            return returnValor;
        }
        
        public int retrnf(String mI, String nI){
            int returnValor =0;
            //pegar o topa da pilha como retorno da função
            funValor = dataStack.get(stackPointer);
            dataStack.remove(stackPointer);
            stackPointer--;
            this.dalloc(mI, nI);
            returnValor = this.retrn();
            //joga resultado no topo da pilha para ser usado na proxima
            dataStack.add(funValor);
            stackPointer++;
            return returnValor;
        }
}