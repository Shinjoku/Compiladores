package my.compilador;

import java.util.ArrayList;
import java.util.Optional;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Felipe
 */
public class Semantic {
    public ArrayList<Identifier> symbolsTable = new ArrayList();
    private Symbol symbols;
    private int level=0;
    
    //modificar para nossa nescessidade de multiplas classes
    public void stackTable(String lexem, String type, int level, int label){
        switch (type){
            case "function":
                symbolsTable.add(new Function(lexem, level));
                break;
            case "var":
                symbolsTable.add(new Variable(lexem, level));
                break;
            case "procedure":
                symbolsTable.add(new Procedure(lexem, level));
                level++;
                break;
            default:
                //colocar error
                break;
        }
    }
    
    //busca se nome de variavel já está usado
    public boolean doubleVarSearch(String lexema){
        for(int i = symbolsTable.size(); i <=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema)){
                return true;
            }
        }
        return false;
    }
    
    public void insertTypeVar(int type){
        int i = symbolsTable.size()-1;
        
        while(symbolsTable.get(i) instanceof Variable && ((Variable)symbolsTable.get(i)).type == null){
            System.out.println(i);
            System.out.println(symbolsTable.get(i).lexem);
            /*if(type == symbols.sinteger){
                ((Variable)symbolsTable.get(i)).setType("integer");
            }
            else{
                ((Variable)symbolsTable.get(i)).setType("boolean");
            }*/
            
            i--;
        }
    }
    
    //verifica se variavel usada está declarada como variavel
    public boolean varDeclSearch(String lexema){
        for(int i = symbolsTable.size()-1; i<=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema) && (symbolsTable.get(i) instanceof Variable)){
                return true;
            }
        }
        return false;
    }
    
    //verifica se identificar é declarado como variavel ou função
    public boolean varFucnDeclSearch(String lexema){
        for(int i = symbolsTable.size()-1; i<=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema) && !(symbolsTable.get(i) instanceof Procedure)){
                return true;
            }
        }
        return false;
    }
    
    public boolean procDeclSearch(String lexema){
        for(int i = symbolsTable.size()-1; i<=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema) && (symbolsTable.get(i) instanceof Procedure)){
                return true;
            }
        }
        return false;
    }
    
    public boolean funcDeclSearch(String lexema){
        for(int i = symbolsTable.size()-1; i<=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema) && (symbolsTable.get(i) instanceof Function)){
                return true;
            }
        }
        return false;
    }
    
    public void unstackTable(){
        do{
            symbolsTable.remove(symbolsTable.size()-1);
        }while(symbolsTable.get(symbolsTable.size()-1).level >= symbolsTable.get(symbolsTable.size()-2).level);
    }
    
    public void printPoint(){
        System.out.println("SEMANTIC> "+symbolsTable.get(symbolsTable.size()-1).lexem +" Level: "+ symbolsTable.get(symbolsTable.size()-1).level);
        if(symbolsTable.get(symbolsTable.size()-1) instanceof Variable){
            System.out.println("SEMANTIC>"+((Variable)symbolsTable.get(symbolsTable.size()-1)).level);
        }
        else{
            if(symbolsTable.get(symbolsTable.size()-1) instanceof Function){
                System.out.println("SEMANTIC>"+((Variable)symbolsTable.get(symbolsTable.size()-1)).level);
            }
        }
            
        
    }
}
