package my.compilador;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Felipe
 */
public class Semantic {
    public ArrayList<Identifier> symbolsTable = new ArrayList();
    private Symbol symbols = new Symbol();
    private int level=0;
    private static ArrayList<String> postfix = new ArrayList();
    private static ArrayList<Token> postfixTable = new ArrayList();
    
    private static ArrayList<String> booleanString = new ArrayList<>(Arrays.asList(">=", ">", "<=", "<", "e", "ou"));
    private static String intString[] = new String[]{"+", "-", "div", "*"};
    
    //modificar para nossa nescessidade de multiplas classes
    public void stackTable(String lexem, String type, int level, int label){
        switch (type){
            case "function":
                symbolsTable.add(new Function(lexem, level));
                break;
            case "var":
                symbolsTable.add(new Variable(lexem, level));
                break;
            case "procedure":
                symbolsTable.add(new Procedure(lexem, level));
                break;
            default:
                //colocar error
                break;
        }
    }
    
    //busca se nome de variavel já está usado
    public boolean doubleVarSearch(String lexema){
        for(int i = symbolsTable.size(); i <=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema)){
                return true;
            }
        }
        return false;
    }
    
    public void insertTypeVar(int typesend){
        int i = symbolsTable.size()-1;
        
        while(symbolsTable.get(i) instanceof Variable && ((Variable)symbolsTable.get(i)).type == null){
            if(typesend == symbols.sinteger){
                ((Variable)symbolsTable.get(i)).setType("integer");
            }
            else{
                ((Variable)symbolsTable.get(i)).setType("boolean");
            }
            
            i--;
        }
    }
    
    public void insertTypeFuction(int typesend){
        int i = symbolsTable.size()-1;
        
        if(typesend == symbols.sinteger){
                ((Function)symbolsTable.get(i)).setType("integer");
        }
        else{
            ((Function)symbolsTable.get(i)).setType("boolean");
        }
    }
    //verifica se variavel usada está declarada como variavel
    public int varDeclSearch(String lexema){
        for(int i = symbolsTable.size()-1; i>=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema) && (symbolsTable.get(i) instanceof Variable)){
                return i;
            }
        }
        return -1;
    }
    
    //verifica se identificar é declarado como variavel ou função
    public int varFucnDeclSearch(String lexema){
        
       for(int i = symbolsTable.size()-1; i>=0; i--){
           if(symbolsTable.get(i).lexem.equals(lexema) && (!(symbolsTable.get(i) instanceof Procedure))){
               return i;
           }
        }
        //System.out.println("h4");
        return -1;
    }
    
    public boolean procDeclSearch(String lexema){
        for(int i = symbolsTable.size()-1; i>=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema) && (symbolsTable.get(i) instanceof Procedure)){
                return true;
            }
        }
        return false;
    }
    
    public int funcDeclSearch(String lexema){
        for(int i = symbolsTable.size()-1; i>=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema) && (symbolsTable.get(i) instanceof Function)){
                return i;
            }
        }
        return -1;
    }
    
    public int positionTable(String lexema){
        for(int i = symbolsTable.size()-1; i>=0; i--){
            if(symbolsTable.get(i).lexem.equals(lexema)){
                return i;
            }
        }
        return -1;
    }
    
    public String typeReturn(int position){
        if(symbolsTable.get(position) instanceof Variable){
            return ((Variable)symbolsTable.get(position)).type;
        }
        else{
            if(symbolsTable.get(position) instanceof Function){
                return ((Function)symbolsTable.get(position)).type;
            }
            else{
                return "error";
            }
        }
    }
    
    public void unstackTable(int currentLevel){
        int count = symbolsTable.size()-1;
        this.printPoint();
        //System.out.println("hi"+currentLevel);
        while(symbolsTable.get(count).level == currentLevel){
            //System.out.println(symbolsTable.get(count).level);
            symbolsTable.remove(count);
            count--;
            if(count<0){
                break;
            }
        }
        this.printPoint();
    }
    
    public void printPoint(){
        if(symbolsTable.size()>0){
            for(int i = symbolsTable.size()-1; i>=0; i--){
                System.out.println("SEMANTIC> "+symbolsTable.get(i).lexem +" Level: "+ symbolsTable.get(i).level);
                if(symbolsTable.get(i) instanceof Variable){
                    System.out.println("SEMANTIC>"+((Variable)symbolsTable.get(i)).type);
                    //&& ((Variable)symbolsTable.get(i)).type != null
                }
                else{
                    if(symbolsTable.get(i) instanceof Function){
                        System.out.println("SEMANTIC>"+((Function)symbolsTable.get(i)).type);
                    }
                }
            }
        }
        else{
            System.out.println("SEMANTIC> Table empty");
        }
    }
    
    public int returnFunction(int currentLevel){
        int count = symbolsTable.size()-1;
        while(symbolsTable.get(count).level == currentLevel){
            count--;
            if(count<0){
                return -1;
            }
        }
        return count;
    }
    
    
    //------------------POSFIX FUNCTIONS---------------------//
    //------------------ADDING OPERATEDED TO POSFIX---------------//
    public void posfixTextAdd(String addingText){
        postfix.add(addingText);
    }
    
    public void posfixTableAdd(Token addingToken){
        postfixTable.add(addingToken);
    }
    
    //-------------------USING POSFIXTABLE TO ADD OPERATORS TO POSFIX------//
    public void posfixTableHandler(int postLevel){
        for(int count = postfixTable.size()-1; count>=0; count--){
            if(postLevel == -2){
                if(postfixTable.get(count).getSymbol() == -1){
                    postfixTable.remove(count);
                    break;   
                }
                else{
                    posfixTextAdd(postfixTable.get(count).getLexeme());
                    postfixTable.remove(count);
                }
            }
            else{
                if(postLevel == -3){
                    posfixTextAdd(postfixTable.get(count).getLexeme());
                    postfixTable.remove(count);
                }
                else{
                    if(postfixTable.get(count).getSymbol() >= postLevel){
                        posfixTextAdd(postfixTable.get(count).getLexeme());
                        postfixTable.remove(count);
                    }
                    else{
                        break;
                    }
                }

            }    
        }
    }
    
    public ArrayList getPosfix(){
        return postfix;
    }
    
    public void printPosfix(){
        for(int count = 0; count<postfix.size(); count++){
            System.out.print(postfix.get(count));
        }
        System.out.print('\n');
    }
    
    public void errasePosfix(){
        for(int count = postfix.size()-1; count>=0; count--){
            postfix.remove(count);
        }
    }
    
    public String posfixType(){
        if(booleanString.contains(postfix.get(postfix.size()-1))){
            return "boolean";
        }
        else{
            return "integer";
        }
    }
}
