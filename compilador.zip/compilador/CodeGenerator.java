/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.compilador;


/**
 *
 * @author Felipe
 */
public class CodeGenerator {
    private String finalText = new String();
    private int varcount = 0;
    private int varPosition = 0;
    
    
    public void Create(Object rotulo, String command, Object target1, Object target2){
        finalText = finalText + rotulo + " " + command + " " + target1 + " " + target2 + "\n";
    }
    
    public String getFinalText(){
        return finalText;
    }
    
    public void addVarCount(){
        varcount++;
    }
    
    public void clearVarCount(){
        varcount = 0;
    }
    
    public int getVarCount(){
        return varcount;
    }
    
    public void setVarPosition(int plus){
        varPosition = varPosition + plus;
    }
    
    public int getVarPosition(){
        return varPosition;
    }
}
