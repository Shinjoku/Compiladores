/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.compilador;

/**
 *
 * @author Felipe
 */
public class Function extends Identifier{
    public String type;
    private boolean returnFlag;
    
    public Function (String lexem, int level){
        this.lexem = lexem;
        this.level = level;
    }
    
    public void setType(String type){
        this.type = type;
    }
    
    public void setFlag(boolean setflag){
        this.returnFlag = setflag;
    }
    
    public boolean getFlag(){
        return this.returnFlag;
    }
}
