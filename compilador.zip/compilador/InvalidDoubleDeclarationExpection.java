/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.compilador;

import com.sun.javafx.applet.ExperimentalExtensions;

/**
 *
 * @author Felipe
 */
public class InvalidDoubleDeclarationExpection extends Exception{
    public InvalidDoubleDeclarationExpection(String message){
        super(message);
    }
}
