/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.compilador;

/**
 *
 * @author Felipe
 */
public class Procedure extends Identifier{
    public int rotulo;
    
    public Procedure (String lexema, int level, int rotulo){
        this.lexem = lexema;
        this.level = level;
        this.rotulo = rotulo;
    }
}
