/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.compilador;

/**
 *
 * @author Felipe
 */
public class Function extends Identifier{
    public String type;
    private boolean returnFlag;
    public int rotulo;
    
    public Function (String lexem, int level, int rotulo){
        this.lexem = lexem;
        this.level = level;
        this.rotulo = rotulo;
    }
    
    public void setType(String type){
        this.type = type;
    }
    
    public void setFlag(boolean setflag){
        this.returnFlag = setflag;
    }
    
    public boolean getFlag(){
        return this.returnFlag;
    }
}
